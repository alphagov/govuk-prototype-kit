# Cookies

The GOV.UK Prototype Kit puts small files (known as ‘cookies’) on to your computer.

We use cookies to:

- record the notifications you've seen so we don't show them again
- measure how you use the website so it can be updated and improved based on your activity

These cookies aren’t used to identify you personally.

You’ll see a message on the site before we store a cookie on your computer.

[Find out how to manage cookies.](https://ico.org.uk/for-the-public/online/cookies/)

## Our cookie message

You will see a message about cookies when you first visit the GOV.UK Prototype Kit. We’ll store a cookie so that your computer knows you’ve seen it and knows not to show it again.

{% from "table/macro.njk" import govukTable %}

{{ govukTable({
  "caption": "Dates and amounts",
  "captionClasses": "govuk-visually-hidden",
  "firstCellIsHeader": false,
  "classes": "app-table--fixed",
  "head": [
    {
      "text": "Name"
    },
    {
      "text": "Purpose"
    },
    {
      "text": "Expires"
    }
  ],
  "rows": [
    [
      {
        "text": "seen_cookie_message"
      },
      {
        "text": "Saves a message to let us know that you have seen our cookie message"
      },
      {
        "text": "28 days"
      }
    ]
  ]
}) }}

## Measuring website usage with Google Analytics

We use Google Analytics software to collect information about how you use the GOV.UK Prototype Kit. We do this to help make sure the site is meeting the needs of its users and to help us make improvements.

Google Analytics stores information about:

- the pages you visit
- how long you spend on each page
- how you got to the site
- what you click on while you’re visiting the site.

We don’t collect or store your personal information, so this data can’t be used to identify who you are. For more information visit our [privacy policy](/docs/privacy-policy) page.

We don’t allow Google to use or share our analytics data.

Google Analytics sets the following cookies:

{{ govukTable({
  "caption": "Dates and amounts",
  "captionClasses": "govuk-visually-hidden",
  "firstCellIsHeader": false,
  "classes": "app-table--fixed",
  "head": [
    {
      "text": "Name"
    },
    {
      "text": "Purpose"
    },
    {
      "text": "Expires"
    }
  ],
  "rows": [
    [
      {
        "text": "_ga"
      },
      {
        "text": "This helps us count how many people visit the GOV.UK Prototype Kit site by tracking if you’ve visited before"
      },
      {
        "text": "2 years"
      }
    ],
    [
      {
        "text": "_gid"
      },
      {
        "text": "This helps us count how many people visit the GOV.UK Prototype Kit site by tracking if you’ve visited before"
      },
      {
        "text": "24 hours"
      }
    ],
    [
      {
        "text": "_gat"
      },
      {
        "text": "This is used to limit the rate at which page view requests are recorded by Google"
      },
      {
        "text": "1 minute"
      }
    ]
  ]
}) }}
