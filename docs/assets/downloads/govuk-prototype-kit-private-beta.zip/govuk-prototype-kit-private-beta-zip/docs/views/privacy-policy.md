# Privacy policy

We collect certain information and data about you when you use the GOV.UK Prototype Kit.

We collect:

- questions, queries or feedback you leave
- your email address, if you contact us
- your Internet Protocol (IP) address, and which version of web browser you used
- information on how you use the site, using [cookies](/docs/cookies) and page-tagging techniques

This data can be viewed by authorised people in the [Government Digital Service](https://www.gov.uk/government/organisations/government-digital-service) (GDS) and our suppliers, to:

- improve the site by monitoring how you use it
- gather feedback to improve our services
- respond to any feedback you send us, if you’ve asked us to.

## Where your data is stored

We store your data on secure servers in the [European Economic Area](https://www.gov.uk/eu-eea) (EEA).

## Keeping your data secure

Sending information over the internet is generally not completely secure, and we can’t guarantee the security of your data while it’s in transit.

**Any data you send is at your own risk**.

We have procedures and security features in place to keep your data secure once we receive it.

## Disclosing your information

We may pass on your personal information if we have a legal obligation to do so, or if we have to enforce or apply our [terms of use](https://www.gov.uk/help/terms-conditions) and other agreements. This includes exchanging information with other government departments for legal reasons.

We won’t share your information with any other organisations for marketing, market research or commercial purposes, and we don’t pass on your details to other websites.

## Your rights

You can [find out what information we hold about you](https://www.gov.uk/data-protection), and [ask us not to use any of the information we collect](https://www.gov.uk/contact).

## Links to other websites

The GOV.UK Prototype Kit contains links to other websites.

This privacy policy only applies to the GOV.UK Prototype Kit, and doesn’t cover other government services and transactions that we link to. These services have their own terms and conditions and privacy policies.

### Following a link to another website

If you go to another website from this one, read the privacy policy on that website to find out what it does with your information.

### Following a link to the GOV.UK Prototype Kit from another website

If you come to the GOV.UK Prototype Kit from another website, we may receive information from the other website. We don’t use this data. You should read the privacy policy of the website you came from to find out more about this.
